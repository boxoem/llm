import streamlit as st


def app():
    st.title("Welcome to the Guessing Game!")
    st.write("Test your guessing skills!")
    st.write(
        "Navigate to the **Game** page to start playing or to **Results** to see your scores."
    )
